package com.montaury.citadels;
import com.montaury.citadels.district.Card;
import com.montaury.citadels.round.GameRoundAssociations;
import com.montaury.citadels.player.Player;
import com.montaury.citadels.round.Group;
import com.montaury.citadels.character.Character;
import io.vavr.collection.List;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class GameRoundsAssociationTest {

    private Board board;
    private GameRoundAssociations groups;
    private Player j1;
    private Player j2;
    private Player j3;

    @Before
    public void set_up() {
        board = new Board();
        City city1 = new City(board);
        City city2 = new City(board);
        City city3 = new City(board);
        j1 = new Player("Paul", 50, city1,null);
        j2 = new Player("Paul", 50, city2,null);
        j3 = new Player("Paul", 50, city3,null);
        j1.add(2);
        j2.add(2);
        j3.add(2);
        List<Group> associations = List.empty();
        associations = associations.append(new Group(j1, Character.ABBOT));
        associations = associations.append(new Group(j2, Character.ARCHITECT));
        associations = associations.append(new Group(j3, Character.KING));
        groups = new GameRoundAssociations(associations);
    }

    @Test
    public void player2_should_be_richest() {
        groups.associations.get(1).player().add(4);
        assertThat(groups.getRichestPlayers().head()).isEqualTo(j2);
    }

    @Test
    public void player1_and_player2_should_be_richest() {
        groups.associations.get(0).player().add(4);
        groups.associations.get(1).player().add(4);
        List<Player> listToFind = List.empty();
        listToFind = listToFind.append(groups.associations.get(1).player());
        listToFind = listToFind.append(groups.associations.get(2).player());

        assertThat(groups.getRichestPlayers()).contains(j1);
        assertThat(groups.getRichestPlayers()).contains(j2);
        assertThat(groups.getRichestPlayers()).doesNotContain(j3);
    }

    @Test
    public void player2_should_pay_player1 () {

        groups.associations.get(1).player().add(4);

        if ( !groups.getRichestPlayers().contains(j1) &&  groups.getRichestPlayers().size() == 1 ) {
            groups.getRichestPlayers().head().pay(1);
            groups.associations.get(0).player().add(1);
        }
        assertThat(groups.associations.get(0).player().gold()).isEqualTo(3);
        assertThat(groups.associations.get(1).player().gold()).isEqualTo(5);

    }

    @Test
    public void no_one_should_pay_player1 () {
        groups.associations.get(1).player().add(4);
        groups.associations.get(2).player().add(4);

        if (!groups.getRichestPlayers().contains(j1) &&  groups.getRichestPlayers().size() == 1 ) {
            groups.getRichestPlayers().head().pay(1);
            groups.associations.get(0).player().add(1);
        }
        assertThat(groups.associations.get(0).player().gold()).isEqualTo(2);
        assertThat(groups.associations.get(1).player().gold()).isEqualTo(6);
        assertThat(groups.associations.get(2).player().gold()).isEqualTo(6);
    }

}
