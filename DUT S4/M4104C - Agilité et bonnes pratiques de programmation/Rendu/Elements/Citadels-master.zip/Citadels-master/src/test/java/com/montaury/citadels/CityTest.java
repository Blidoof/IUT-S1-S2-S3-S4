package com.montaury.citadels;

import com.montaury.citadels.district.Card;
import com.montaury.citadels.player.Player;
import io.vavr.collection.HashSet;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class CityTest {

    private Board board;
    private City city;

    @Before
    public void set_up() {
        board = new Board();
        city = new City(board);
    }

    @Test
    public void score_should_be_equal_to_added_construction_costs() {
        city.buildDistrict(Card.MARKET_3);
        city.buildDistrict(Card.TOWN_HALL_2);
        city.buildDistrict(Card.KEEP_2);
        city.buildDistrict(Card.MARKET_1);
        Possession possession = new Possession(0,null);
        int score = city.score(possession);
        assertThat(score).isEqualTo(12);
    }

    @Test
    public void score_should_have_plus_three_bonus_if_five_types_of_district() {
        city.buildDistrict(Card.TEMPLE_1);
        city.buildDistrict(Card.TAVERN_1);
        city.buildDistrict(Card.WATCHTOWER_1);
        city.buildDistrict(Card.MANOR_1);
        city.buildDistrict(Card.LIBRARY);
        Possession possession = new Possession(0,null);
        int score = city.score(possession);
        assertThat(score).isEqualTo(15);
    }

    @Test
    public void score_should_have_plus_four_bonus_if_player_finished_first() {
        city.buildDistrict(Card.MARKET_3);
        city.buildDistrict(Card.TOWN_HALL_2);
        city.buildDistrict(Card.KEEP_2);
        city.buildDistrict(Card.MARKET_1);
        city.buildDistrict(Card.TOWN_HALL_1);
        city.buildDistrict(Card.KEEP_1);
        city.buildDistrict(Card.MARKET_2);
        Possession possession = new Possession(0,null);
        int score = city.score(possession);
        assertThat(score).isEqualTo(26);
    }

    @Test
    public void score_should_have_plus_two_bonus_if_player_finished_not_first() {
        city.buildDistrict(Card.MARKET_3);
        city.buildDistrict(Card.TOWN_HALL_2);
        city.buildDistrict(Card.KEEP_2);
        city.buildDistrict(Card.MARKET_1);
        city.buildDistrict(Card.TOWN_HALL_1);
        city.buildDistrict(Card.KEEP_1);
        city.buildDistrict(Card.MARKET_2);

        City city2 = new City(board);
        city2.buildDistrict(Card.MARKET_3);
        city2.buildDistrict(Card.TOWN_HALL_2);
        city2.buildDistrict(Card.KEEP_2);
        city2.buildDistrict(Card.MARKET_1);
        city2.buildDistrict(Card.TOWN_HALL_1);
        city2.buildDistrict(Card.KEEP_1);
        city2.buildDistrict(Card.MARKET_2);

        Possession possession = new Possession(0,null);
        int score = city2.score(possession);
        assertThat(score).isEqualTo(24);
    }

    @Test
    public void score_should_have_bonus_according_to_hand_when_owning_map_room() {
        city.buildDistrict(Card.MAP_ROOM);
        Player player = new Player("Arthur",43,city,null);
        Possession possession = new Possession(0, HashSet.of(Card.TEMPLE_1,Card.TOWN_HALL_1));
        int score = city.score(possession);
        assertThat(score).isEqualTo(7);
    }

    @Test
    public void score_should_have_bonus_according_to_gold_when_owning_treasury() {
        city.buildDistrict(Card.TREASURY);
        Player player = new Player("Arthur",43,city,null);
        Possession possession = new Possession(5,null);
        int score = city.score(possession);
        assertThat(score).isEqualTo(10);
    }

    @Test
    public void score_should_have_score_bonus_when_owning_dragon_gate_or_university() {
        city.buildDistrict(Card.UNIVERSITY);
        city.buildDistrict(Card.DRAGON_GATE);
        Possession possession = new Possession(0,null);
        int score = city.score(possession);
        assertThat(score).isEqualTo(16);
    }
}