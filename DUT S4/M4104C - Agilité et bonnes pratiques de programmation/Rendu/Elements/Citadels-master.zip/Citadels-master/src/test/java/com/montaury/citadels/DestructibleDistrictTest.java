package com.montaury.citadels;

import com.montaury.citadels.district.Card;
import com.montaury.citadels.district.District;
import com.montaury.citadels.player.Player;
import com.montaury.citadels.round.action.DestroyDistrictAction;
import io.vavr.collection.HashSet;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class DestructibleDistrictTest {

    private Board board;
    private City city;

    @Before
    public void set_up() {
        board = new Board();
        city = new City(board);
    }

    @Test
    public void city_should_be_destroyed() {
        city.buildDistrict(Card.DRAGON_GATE);
        city.buildDistrict(Card.LIBRARY);
        city.destroyDistrict(Card.LIBRARY);
        assertThat(city.districts().size()).isEqualTo(1);
    }

}
