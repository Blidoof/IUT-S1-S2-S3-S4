package com.montaury.citadels.district;

public enum DistrictType {
    NOBLE, RELIGIOUS, TRADE, MILITARY, SPECIAL
}
