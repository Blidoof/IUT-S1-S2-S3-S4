package com.montaury.citadels.round;

import com.montaury.citadels.character.Character;
import com.montaury.citadels.player.Player;
import io.vavr.collection.List;
import io.vavr.control.Option;

public class GameRoundAssociations {

    public GameRoundAssociations(List<Group> associations) {
        this.associations = associations;
    }

    public Option<Group> associationToCharacter(Character character) {
        return associations.find(a -> a.character == character);
    }

    public List<Player> getRichestPlayers() {
        List<Player> richestPlayers = List.empty();

        //Assume first player in associations is the richest
        richestPlayers = richestPlayers.append(associations.head().player());

        //Search for players richer than or as rich as assumed richest player
        for (Group association : associations ) {
            if (association.player().gold() > richestPlayers.head().gold()) {
                //If a player is richer we empty the list, put the player in and search for richer or as much as rich
                richestPlayers = List.empty();
                richestPlayers = richestPlayers.append(association.player());
            }
            if (association.player().gold() == richestPlayers.head().gold()) {
                //To make sure the same player isn't added twice because of the assumption we made
                if(!richestPlayers.contains(association.player())) {
                    //If a player is as rich as the richest then we put it in the list
                    richestPlayers = richestPlayers.append(association.player());
                }

            }
        }
        return richestPlayers;
    }

    public final List<Group> associations;
}
