<?php

$string = file_get_contents("maladesCovid19.json");
$malades = json_decode($string, true);

$resultatRenvoye = array();

//C'est moche je sais mais j'avais pas le temps de trouver mieux
foreach ($malades as $key => $malade) {

  if (isset($_GET["Personne"])) {
    if (strcmp($malade["Personne"], $_GET["Personne"] ) != 0) { // Si le parametre personne est défini et que le malade courant ne correspond pas on passe au suivant
      continue;
    }
  }

  if (isset($_GET["Date"])) {
    if (strcmp($malade["Date"], $_GET["Date"] ) != 0) { // Si le parametre date est défini et que le malade courant ne correspond pas on passe au suivant
      continue;
    }
  }

  if (isset($_GET["Adresse"])) {
    if (strcmp($malade["Date"], $_GET["Date"] ) != 0) { // Si le parametre Adresse est défini et que le malade courant ne correspond pas on passe au suivant
      continue;
    }
  }

  if (isset($_GET["Ville"])) {
    if (strcmp($malade["Ville"], $_GET["Ville"] ) != 0) { // Si le parametre Ville est défini et que le malade courant ne correspond pas on passe au suivant
      continue;
    }
  }

  if (isset($_GET["CP"])) {
    if (strcmp($malade["CP"], $_GET["CP"] ) != 0) { // Si le parametre CP est défini et que le malade courant ne correspond pas on passe au suivant
      continue;
    }
  }

  $resultatRenvoye[] = $malade; // On ajoute le malade courant au tableau de réasultat qui sera envoyé (il est ajouté si il satisfait tous les paramètres passés)
                                // Si il n'y en a pas ils sont tous ajoutés

  header("Content-Type: text/javascript");
  echo json_encode($resultatRenvoye); // On renvoie le résultat de la requête
}
